//
//  ViewController.m
//  加密终极版
//
//  Created by suxsoft-mac1 on 16/1/26.
//  Copyright © 2016年 suxsoft-mac1. All rights reserved.
//

#import "ViewController.h"
#import "NSString+AES128.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
 
    NSData *keyData =  [NSString stringToByte:KEY];
    NSData *ivData =  [NSString stringToByte:IV];
    NSString * content = @"hello world";
    
    NSString * encrypt = [content AES128EncryptWithKey:keyData iv:ivData];
    
    NSLog(@"加密：%@",encrypt);
    
    NSString * decrypt = [encrypt AES128DecryptWithKey:keyData iv:ivData];
    
    NSLog(@"解密：%@",decrypt);
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
