//
//  NSData+AES128.h
//  加密终极版
//
//  Created by suxsoft-mac1 on 16/1/26.
//  Copyright © 2016年 suxsoft-mac1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (AES128)
- (NSData *)AES128EncryptWithKey:(NSData *)key iv:(NSData *)iv;   //加密
- (NSData *)AES128DecryptWithKey:(NSData *)key iv:(NSData *)iv;   //解密


@end
