//
//  NSString+AES128.h
//  加密终极版
//
//  Created by suxsoft-mac1 on 16/1/26.
//  Copyright © 2016年 suxsoft-mac1. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (AES128)
/**
 *  加密
 */
- (NSString *)AES128EncryptWithKey:(NSData *)key iv:(NSData *)iv;

/**
 *  解密
 */
- (NSString *)AES128DecryptWithKey:(NSData *)key iv:(NSData *)iv;

/**
 *   16进制数－>Byte数组
 */
+ ( NSData *)stringToByte:(NSString *)hexString;

/**
 *   Byte数组－>16进制数
 */
+ (NSString *)byteToString:(Byte *)byte;


@end
