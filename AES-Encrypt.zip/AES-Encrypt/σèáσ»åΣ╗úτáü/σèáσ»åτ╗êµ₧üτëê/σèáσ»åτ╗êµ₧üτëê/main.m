//
//  main.m
//  加密终极版
//
//  Created by suxsoft-mac1 on 16/1/26.
//  Copyright © 2016年 suxsoft-mac1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
