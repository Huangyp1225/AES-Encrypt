//
//  NSString+AES128.m
//  加密终极版
//
//  Created by suxsoft-mac1 on 16/1/26.
//  Copyright © 2016年 suxsoft-mac1. All rights reserved.
//

#import "NSString+AES128.h"
#import "NSData+AES128.h"
@implementation NSString (AES128)


//加密
- (NSString *)AES128EncryptWithKey:(NSData *)key iv:(NSData *)iv;
{

    NSData *plainTextData = [self dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData *cipherTextData = [plainTextData AES128EncryptWithKey:key iv:(NSData *)iv];
    
    
    Byte *plainTextByte = (Byte *)[cipherTextData bytes];
    
    NSMutableString * output = [NSMutableString stringWithCapacity:cipherTextData.length * 2];
    
    
    for(int i=0;i<[cipherTextData length];i++){
        
        [output appendFormat:@"%02x",plainTextByte[i]];
        
    }
    
    return output;
    
}

//解密
- (NSString *)AES128DecryptWithKey:(NSData *)key iv:(NSData *)iv
{
    //转换为2进制Data
    NSMutableData *data = [NSMutableData dataWithCapacity:self.length / 2];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i;
    for (i=0; i < [self length] / 2; i++) {
        byte_chars[0] = [self characterAtIndex:i*2];
        byte_chars[1] = [self characterAtIndex:i*2+1];
        whole_byte = strtol(byte_chars, NULL, 16);
        [data appendBytes:&whole_byte length:1];
    }
    
    NSData *decryptionData = [data AES128DecryptWithKey:key iv:(NSData *)iv];
    
    NSString *str = [[NSString alloc] initWithData:decryptionData encoding:NSUTF8StringEncoding];
    
    return str;
}


/**
 *   16进制数－>Byte数组
 *
 *  @param hexString 密钥
 *
 *  @return 返回Byte数组
 */
+ ( NSData *)stringToByte:(NSString *)hexString
{
    
    ///// 将16进制数据转化成Byte 数组
    
    int j=0;
    Byte bytes[128];  ///3ds key的Byte 数组， 128位
    for(int i=0;i<[hexString length];i++)
    {
        int int_ch;  /// 两位16进制数转化后的10进制数
        
        unichar hex_char1 = [hexString characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            int_ch1 = (hex_char1-87)*16; //// a 的Ascll - 97
        i++;
        
        unichar hex_char2 = [hexString characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            int_ch2 = hex_char2-87; //// a 的Ascll - 97
        
        int_ch = int_ch1+int_ch2;
        //        NSLog(@"int_ch=%d",int_ch);
        bytes[j] = int_ch;  ///将转化后的数放入Byte数组里
        j++;
    }
    NSData *newData = [[NSData alloc] initWithBytes:bytes length:128];
    //    NSLog(@"newData=%@",newData);
    
    //    for (int i = 0;  i <[newData length]; i++) {
    //        printf("%d ",bytes[i]);
    //    }
    
    return newData;
}

/**
 *   Byte数组－>16进制数
 *
 *  @param byte  Byte数组
 *
 *  @return 16进制字符串
 */
+ (NSString *)byteToString:(Byte *)byte
{
    NSData *data = [[NSData alloc] initWithBytes:byte length:128];
    NSString *hexStr=@"";
    
    for(int i=0;i<[data length];i++)
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",byte[i]&0xff];///16进制数
        if([newHexStr length]==1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
//    NSLog(@"bytes 的16进制数为:%@",hexStr);

    return hexStr;
}

@end
